//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include <dstring.h>
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm2::ComboBox1KeyPress(TObject *Sender, char &Key)
{
ComboBox1->SetFocus();
	 if (Key==13)
	 {
	 ListBox1->Items->Add(ComboBox1->Text);
	 ComboBox1->Items->Add(ComboBox1->Text);

	  int p = 1, l = 0;
	  AnsiString str = ComboBox1->Text + " ";
	  AnsiString str2, str3;
	  for (int i=1; i<=str.Length(); i++){
	  if (str[i] == ' '){
		l = i;
		str2 = str.SubString(p, l - p);
		p = l;
		str.Delete(1, l - p + 1);
	  ListBox1->Items->Add(str2);
	  break;
	  }
	  }
	  ComboBox1->Text="";
	  }
}
//---------------------------------------------------------------------------


void __fastcall TForm2::ListBox1Click(TObject *Sender)
{
int r = 0 ,j = 0, k, s;
char p;
int y = ListBox1->ItemIndex;
AnsiString str2 = ListBox1->Items->Strings[y];
  for ( int i = 1; i < str2.Length(); i++)
	 {
	  if ( str2[i] == 69)
	  {
	   k = i;
	   r++;
	  }
	  else
	  {
	   if (str2[i] == 43 || str2[i] == 45)
	   {
		s = i;
		j++;
	   }
	  }
	 }
  if ( r == 1 && j == 1)
	{
	  if (k+1 == s)
	  {
		for(int i= 1; i< k; i++)
		{
		 if ( str2[i]>= 48 && str2[i] <= 57)
		 {
		  Label2->Caption = "�������������� ������������� �����";
		 }
		 else Label2->Caption = "�� �����";
		}
	  }
	}
  else
  {
   if ( j > 1 || r > 1)
   {
	Label2->Caption = "�� �����";
   }
   else Label2->Caption = "����� ������������� �����";
  }
}

//--------------------------------------------------------------------------

